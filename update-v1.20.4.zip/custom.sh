#!/system/bin/sh
if [ ! -d "/tool_files" ] && [ -d "/system/.tool" ]; then
mkdir -p /tool_files/work
mv /system/.tool /tool_files/main
ln -s /tool_files/main /system/.tool
mv /data/adb/script /tool_files/work/script
fi


# Load tool util function
. /system/.tool/exbin/utils
# load new path for terminal
sh /system/.tool/exbin/exbin