#################
# VMOS TOOL FLASH CONFIG
#################

# Source util functions

[ ! -f "/tool_files/main/exbin/utils" ] && echo "! Please install lastest vmostool" && touch error && exit 1;
. /tool_files/main/exbin/utils
[ "$TOOLVERCODE" -lt 12100 ] && echo "! Please install vmostool v1.21+" && touch error && exit 1;
find_bb=`which busybox`
[ ! "$find_bb" ] && echo "! Please install Busybox" && touch error && exit 1;

# Busybox is in /tool_files/main/exbin/busybox

# == REMOVE LIST ==

# Example: I want to delete /system/app/YouTube

REMOVE_LIST="
/system/app/YouTube
"
# List folders and files here if you want to remove, this will overwrite values above!
REMOVE_LIST="

"
# == IGNORE PLACE ==
# Set to true of you don't want place any file into /system
IGNORE_PLACE=false

# == SCRIPT ==
# Input your post-fs-data script name here

POSTFSDATA=

# Input your late_start script name here

LATESTART=

### You can write your script here!!

echo "TEMPLATE MOD"
echo "by HusyDG"