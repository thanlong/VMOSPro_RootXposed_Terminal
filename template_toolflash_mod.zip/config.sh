#################
# VMOS TOOL FLASH CONFIG
#################
# Create <custom_name> folder in
# /sdcard/toolflash
# Place system, config.sh, custom.sh at
# /sdcard/toolflash/<custom_name>



# == REMOVE LIST ==

# Example: I want to delete /system/app/YouTube

REMOVE_LIST="
/system/app/YouTube
"


# List folders and files here if you want to remove, this will overwrite values above!
REMOVE_LIST="

"

# == IGNORE PLACE ==
# Set to true of you don't want place any file into /system

IGNORE_PLACE=false

# == SCRIPT ==

# Input your post-fs-data script name here

POSTFSDATA=

# Input your late_start script name here

LATESTART=

# Set to true if you want to apply changes (replace or remove some files /system) only after boot 

APPLY_ON_BOOT=false