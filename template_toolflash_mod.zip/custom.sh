#################
# VMOS TOOL FLASH CONFIG
#################

# Source util functions
source /tool_files/main/exbin/utils
#This script will be excuted after config.sh
# Write your script here