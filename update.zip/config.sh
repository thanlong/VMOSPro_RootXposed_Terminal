#!/system/bin/sh
# Update VMOS Pro Terminal Tool
# Check if VMOS Terminal Tool is installed
[ ! -d "/system/.tool" ] && touch error
chmod -R 777 ./system