#!/system/bin/sh
# Update VMOS Pro Terminal Tool
# Check if VMOS Terminal Tool is installed
[ ! -d "/system/.tool" -o ! -d "/tool_files" ] && touch error
chmod -R 777 ./system
if [ -d "/tool_files" ]; then
IGNORE_PLACE=true
mkdir -p /tool_files/main
cp -R ./system/.tool/* /tool_files/main
fi