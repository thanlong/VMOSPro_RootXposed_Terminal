#!/system/bin/sh

####################
# INSTALL SCRIPT For VM
####################

####################
# Copy files to in system
####################


    

[ ! -f config.sh ] && echo "! Invalid zip" && exit 1; . /tool_files/main/exbin/utils

######################
# Config (Before)
######################

if [ -f config.sh ]; then
 cp config.sh install-script.sh
 echo "

APPLY_ON_BOOT=true
if [ \"\$APPLY_ON_BOOT\" == \"true\" ]; then
BOOTDIR=$WDIR/.boot
for file in \$REMOVE_LIST; do
   
       echo \"rm -rf \$file\" >>\$BOOTDIR/config.sh
   
 done

else
for file in \$REMOVE_LIST; do
   BOOTDIR=$WDIR/.boot
       rm -rf \$file 2>/dev/null
   
 done
fi

if [ ! \"\$IGNORE_PLACE\" == \"true\" ]; then
echo \"- Placing files...\"
cp -a ./system/* \$BOOTDIR/system 2>/dev/null
cp -a ./system/.* \$BOOTDIR/system 2>/dev/null
fi

if [ \"\$POSTFSDATA\" ]; then
cp ./\"\$POSTFSDATA\" \"$WDIR/script/post-fs-data.d/\$POSTFSDATA\"
fi

if [ \"\$LATESTART\" ]; then
cp ./\"\$LATESTART\" \"$WDIR/script/late_start.d/\$LATESTART\"
fi


" >>install-script.sh
 sh install-script.sh
fi





####################
# Custom Script (After)
####################

if [ -f custom.sh ]; then
  sh ./custom.sh
fi


####################
####################


if [ ! -f error ];
then
  echo "- Done!"

else
  echo "! Installation failed"; exit 1;
fi