#!/system/bin/sh

####################
# INSTALL SCRIPT For VM
####################

####################
# Copy files to in system
####################


    

[ ! -f config.sh ] && echo "! Invalid zip" && exit 1;

######################
# Config (Before)
######################

if [ -f config.sh ]; then
 cp config.sh install-script.sh
 echo "


if [ \"\$APPLY_ON_BOOT\" == \"true\" ]; then
BOOTDIR=/data/adb/.boot
for file in \$REMOVE_LIST; do
   
       echo \"rm -rR \$file\" >>\$BOOTDIR/config.sh
   
 done

else
for file in \$REMOVE_LIST; do
   
       rm -rR \$file 2>/dev/null
   
 done
fi

if [ ! \"\$IGNORE_PLACE\" == \"true\" ]; then
echo \"- Placing files...\"
cp -a ./system/* \$BOOTDIR/system 2>/dev/null
cp -a ./system/.* \$BOOTDIR/system 2>/dev/null
fi

if [ \"\$POSTFSDATA\" ]; then
cp ./\"\$POSTFSDATA\" \"/data/adb/script/post-fs-data.d/\$POSTFSDATA\"
fi

if [ \"\$LATESTART\" ]; then
cp ./\"\$LATESTART\" \"/data/adb/script/late_start.d/\$LATESTART\"
fi


" >>install-script.sh
 sh install-script.sh
fi





####################
# Custom Script (After)
####################

if [ -f custom.sh ]; then
  sh ./custom.sh
fi


####################
####################


if [ ! -f error ];
then
  echo "- Done!"

else
  echo "! Installation failed"; exit 1;
fi