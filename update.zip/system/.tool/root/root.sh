#!/system/bin/sh 
SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);
SUVER="Disabled"
DAEMONSU=$(getprop init.svc.daemonsu "stopped") 2>/dev/null
BOOTDIR=
var1=$1

[ ! "$var1" == "9999" ] && sh /tool_files/main/update.sh 9999 2>/dev/null



daemonsu -v &>/dev/null && SUVER=$(daemonsu -v);
SUPATH=$(which su);  . /tool_files/main/exbin/utils
[ ! "$SUPATH" ] && SUPATH=`p red Disabled`
clear;
pd gray "=============================================="
echo "   VMOS SU/ROOT HELPER"
echo "   version 1.8 By HuskyDG"
pd gray "=============================================="
sh ../test_rw.sh
if [ -f /system/xbin/daemonsu ]; then
 if [ "$SDK" == "19" ]; then
   OPTR=3
 else
   echo "Version: $SUVER"
   echo "Path: $SUPATH"
   pd gray "=============================================="
   if [ ! -f fix ]; then
       echo "  1 - Fix Superuser crash"
   else
       echo "  1 - Restore Superuser package"
   fi
   if [ ! -f disable ]; then
       echo "  2 - Hide root access"
   else
       echo "  2 - Un-hide root access"
   fi
   echo "  3 - Uninstall root"
   echo "  4 - Root checker"
   echo "  0 - Exit"
p none "[CHOICE]: "
   read OPTR
 fi


 if [ "$OPTR" == "1" ]; then
    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="
mkdir -p $BOOTDIR/system/app 2>/dev/null
mkdir -p $BOOTDIR/system/xbin 2>/dev/null
    if [ ! -f fix ]; then
        echo "Replacing files..."
        
        chmod 777 /system/xbin/daemonsu 2>/dev/null
        rm -rf fix 2>/dev/null
        touch fix 2>/dev/null
        if [ $SDK == 25 ]; then
            if [ "$AARCH" == "arm64-v8a" ]; then
                echo "Install for Android: 7.1 64bit"
                cp bin/su_25_64_fix $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            else
                echo "Install for Android: 7.1 32bit"
                cp bin/su_25_fix $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            fi
        elif [ $SDK == 22 ]; then
            echo "Install for Android: 5.1 32bit"
            cp bin/su_22_fix $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            cp bin/su10_22_fix $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
        #    chmod 777 $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
        fi
    #    chmod 777 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
       
        echo "Changing superuser app..."
        if [ ! -d $BOOTDIR/system/app/superuser ]; then
            mkdir $BOOTDIR/system/app/superuser 2>/dev/null
        fi
        cp superuser_fix.apk $BOOTDIR/system/app/superuser/superuser.apk 2>/dev/null
        mkdir /data/data/com.koushikdutta.sumasterz 2>/dev/null
        cp -ar /data/data/com.koushikdutta.superuser/* /data/data/com.koushikdutta.sumasterz 2>/dev/null
        echo "Please ignore 'su binary is outdated' notification."

        


    else
        rm -rf fix

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="
mkdir -p $BOOTDIR/system/app 2>/dev/null
mkdir -p $BOOTDIR/system/xbin 2>/dev/null
        echo "Restoring original files..."
        
        chmod 777 /system/xbin/daemonsu 2>/dev/null
        if [ $SDK == 25 ]; then
            if [ "$AARCH" == "arm64-v8a" ]; then
                echo "Install for Android: 7.1 64bit"
                cp bin/su_25_64 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            else
                echo "Install for Android: 7.1 32bit"
                cp bin/su_25 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            fi
        elif [ $SDK == 22 ]; then
            echo "Install for Android: 5.1 32bit"
            cp bin/su_22 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
            cp bin/su10_22 $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
         #   chmod 777 $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
        fi
    #    chmod 777 $BOOTDIR/system/xbin/daemonsu
        echo "Restoring superuser app..."
        if [ ! -d $BOOTDIR/system/app/superuser ]; then
            mkdir $BOOTDIR/system/app/superuser 2>/dev/null
        fi
        cp superuser.apk $BOOTDIR/system/app/superuser/superuser.apk 2>/dev/null
        mkdir /data/data/com.koushikdutta.superuser 2>/dev/null
        cp -ar /data/data/com.koushikdutta.sumasterz/* /data/data/com.koushikdutta.superuser 2>/dev/null
    fi
       
        if [ -f "$BOOTDIR/system/xbin/daemonsu" ]; then
            echo "Done!"
        else
            pd red "Installation failed";exit
        fi
pd gray "=============================================="
        echo "Changes will take effect after reboot"





elif [ "$OPTR" == "0" ]; then
    exit
    echo "Enter to exit!"
elif [ "$OPTR" == "4" ]; then
    echo "Please grant permission if prompted"
    echo "Contact su binary..."
    USER=$(daemonsu -c whoami) &>/dev/null && SUREP="1"
    if [ "$SUREP" == "1" ] && [ "$USER" == "root" ]; then
      pd green "SUCCESS! Root is installed and daemonsu is running properly."
    elif [ "$SUREP" == "1" ]; then
      pd red "FAILED! Root is installed but daemonsu is not running."
      pd red "So you cannot grant root access to any app"
      pd red "Try to shut down and restart virtual machine again."
    else
      pd red "FAILED! Cannot access su binary."
    fi
    read
elif [ "$OPTR" == "2" ]; then
    if [ ! -f disable ]; then
        rm -rf disable 2>/dev/null
        touch disable 2>/dev/null
        FILES="
/system/bin/su
/sbin/su
/system/xbin/su"
  for file in $FILES; do
    rm -rf $file 2>/dev/null
  done
        echo "Root is hidden and disabled!"
    else
        rm -rf disable 2>/dev/null
        FILES="
/sbin/su"
  for file in $FILES; do
    ln -s /system/xbin/daemonsu $file 2>/dev/null
  done
        
        echo "Root is enabled!"
    fi
    
 elif [ "$OPTR" == "3" ]; then

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="
 echo "Do you want to uninstall root?"
 echo "Type yes to continue"
p none "[CHOICE]: "
 read UNR
 if [ "$UNR" == "yes" ]; then
  chmod 777 /system/xbin/daemonsu
  echo "Uninstalling root..."
  FILES="
/system/bin/su
/sbin/su
/system/xbin/daemonsu
/system/xbin/su
/system/xbin/sx
/system/xbin/ku.sud
/system/xbin/ksud
/system/app/superuser.apk"
  for file in $FILES; do
      if [ -f "$file" ]; then
          chmod 777 $file 2>/dev/null
          echo "rm $file" >>$BOOTDIR/config.sh
      fi
  done
  rm disable 2>/dev/null
  rm fix 2>/dev/null
  if [ -f /system/app/superuser/superuser.apk ]; then
      echo "rm -rf /system/app/superuser" >>$BOOTDIR/config.sh
  fi

 
  echo "Done!"
pd gray "=============================================="
  echo "Changes will take effect after reboot"




  exit
 fi
 pd red "Cancelled"
 exit
else
 sh root.sh 9999
 exit
fi
exit


fi

echo "Root is not installed!"
echo "Type yes to install root"
p none "[CHOICE]: "
read ROOT
if [ ! "$ROOT" == "yes" ]; then
  pd red "Cancelled"
  exit
fi



    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="

mkdir -p $BOOTDIR/system/app 2>/dev/null
mkdir -p $BOOTDIR/system/xbin 2>/dev/null

echo "Installing su binary..."
if [ $SDK == 25 ]; then
  if [ "$AARCH" == "arm64-v8a" ]; then
    echo "Install for Android: 7.1 64bit"
    cp bin/su_25_64 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
    else
    echo "Install for Android: 7.1 32bit"
    cp bin/su_25 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
  fi
elif [ $SDK == 22 ]; then
  echo "Install for Android: 5.1 32bit"
  cp bin/su_22 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
  cp bin/su10_22 $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
  chmod 777 $BOOTDIR/system/xbin/daemonsu_10 2>/dev/null
elif [ $SDK == 19 ]; then
  echo "Install for Android: 4.4 32bit"
  cp bin/su_19 $BOOTDIR/system/xbin/daemonsu 2>/dev/null
  cp bin/su_19 $BOOTDIR/system/xbin/ku.sud 2>/dev/null
  cp bin/su_19 $BOOTDIR/system/xbin/ksud 2>/dev/null
else
  pd red "Installation failed"
  exit
fi
if [ ! -f $BOOTDIR/system/xbin/daemonsu ]; then
pd red "Installation failed"
exit
fi

for file in $FILES; do
    if [ ! -f "$file" ]; then
        ln -s $BOOTDIR/system/xbin/daemonsu $BOOTDIR$file 2>/dev/null
    fi
done
echo "Setting permissions..."
FILES="
/system/xbin/daemonsu
/system/xbin/ksud
/system/xbin/ku.sud
"
for file in $FILES; do
    if [ -f "$BOOTDIR$file" ]; then
        chmod 777 $BOOTDIR$file 2>/dev/null
    fi
done

echo "Installing superuser app..."
if [ ! $SDK == 19 ]; then
    if [ ! -d $BOOTDIR/system/app/superuser ]; then
        mkdir $BOOTDIR/system/app/superuser 2>/dev/null
    fi
    cp superuser.apk $BOOTDIR/system/app/superuser/superuser.apk 2>/dev/null
else
    cp kinguser.apk $BOOTDIR/system/app/superuser.apk 2>/dev/null
fi
echo "Done!"
pd gray "=============================================="
echo "Changes will take effect after reboot"

















