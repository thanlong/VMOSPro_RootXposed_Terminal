#!/system/bin/sh

#####################
# VMOS Pro Tool script by HuskyDG
clear
echo "VMOS PRO TERMINAL TOOL"

sh ./update.sh
./busybox/busybox sleep 1


if [ -f "/data/adb/.boot/dual" ]; then
VAR9="Switch to first space"
VAR10="Clear first space data"
sname="first space"
else
VAR9="Switch to second space"
VAR10="Clear second space data"
sname="second space"
fi

if [ -d "/storage/emulated/0" ]; then
SDCARD="/storage/emulated/0"
CSDCARD="/storage/emulated/sdcard"
else
SDCARD="/storage/sdcard"
CSDCARD="/storage/tmp_sdcard"
fi



sdlist=$(find /proc/self/root/storage/* -prune -type d) 2>/dev/null
for sd in $sdlist; do
  if [ -r "$sd/Android" ]; then
  EXTPATH=$sd
  fi
done

bb=/system/.tool/busybox/busybox

ln -s / /system_root &>/dev/null

PACKAGE="
com.vmos.pro
com.vmos.gbi
com.vmos.gbb
"
if [ "$EXTPATH" ]; then
for name in $PACKAGE; do
  mkdir -p $EXTPATH/Android/data/$name/files/expand 2>/dev/null
  if [ -d "$EXTPATH/Android/data/$name/files/expand" ]; then
  EXTPATHFS=$EXTPATH/Android/data/$name/files/expand
  fi
done
fi


SDLINK=$(find $SDCARD -prune -type l) 2>/dev/null
[ "$SDLINK" ] && ISSDLINK=true

VAR8S="Use SD Card as internal storage";VAR8="Use external SD Card as VM memory storage"

[ "$ISSDLINK" == "true" ] && VAR8="Revert internal VM memory storage" && VAR8S="Revert internal storage";
t(){
/system/.tool/exbin/text $1 $2
}
main(){

sdk=$(getprop ro.build.version.sdk);
cpu=$(getprop ro.product.cpu.abi);

clear; VER=1.18.9

# print the ui


echo "****************************"
echo "   VMOS PRO TOOL"
echo "   version $VER By HuskyDG"
echo "****************************"
# test system is rw or not
sh ./test_rw.sh
if [ -f exit ]; then
read
exit
fi
# print options

echo "- 1. Superuser (Root)"
echo "- 2. Xposed Framework"
echo "- 3. Busybox"
echo "- 4. Wipe dalvik-cache"
echo "- 5. VMOS Props Config"
echo "- 6. Install modifications"
echo "- 7. Mount real storage"
echo "- 8. $VAR8S"
echo "- 9. $VAR9"
echo "- 10. $VAR10"
echo "- 11. Google Services"
echo "- X. Exit"
rm -rR /data/adb/flash/* 2>/dev/null
mkdir /sdcard/toolflash 2>/dev/null
rm -rR .tmp/* 2>/dev/null
if [ ! -d ".tmp" ]; then
    mkdir ".tmp"
fi
printf "> "
read ans
if [ "$ans" == "1" ]; then
# execute root script
    cd root
    sh root.sh 9999
elif [ "$ans" == "2" ]; then
# execute xposed script
    cd xposed
    sh xposed.sh 9999
elif [ "$ans" == "3" ]; then
# execute busybox script
    cd busybox
    sh busybox.sh
elif [ "$ans" == "4" ]; then
echo "================================="
   echo "- Wipe dalvik-cache. Are you sure?"
   echo "- Type yes to confirm"
printf "> "
   read wdalvik
   if [ "$wdalvik" == "yes" ]; then
       rm -rR /data/dalvik-cache
       mkdir /data/dalvik-cache
       echo "- Dalvik-cache wiped!"
       echo "- Next boot will take long time."
       read
       sh main.sh
   else
      echo "! Cancelled"
      read
      sh main.sh
      exit
   fi 

elif [ "$ans" == "5" ]; then
  if [ ! -f /vmos.prop ]; then
      echo "- This option is available for VMOS only!"
      read
      sh main.sh
      exit
  fi
clear
echo "================================="
echo " VMOS PROPS CONFIG"
echo "================================="
echo "- Change VMOS property without reboot"
echo "- This will not change anything in vmos.prop file"
echo "- VMOS settings still show old changes"
echo "- 1. View or change property"
echo "- 2. Remove apply changes on boot"
echo "- 3. Merge/unmerge vmos.prop with build.prop"
echo "- Press any key or ENTER to come back to main menu"
printf "> "
read PROPO
if [ "$PROPO" == "1" ]; then
echo "- Press ENTER if you don't want to change in current input"
echo "on property:sys.boot_completed=1" >>.tmp/toolprop.rc


    echo "• Input GPU Vendor"
    GPUV=$(getprop prop.gpu.vendor);
    echo "- Current value: $GPUV" 
printf "> "
    read GPUVC
    if [ ! "$GPUVC" ]; then
        GPUVC=$GPUV
    fi
    if [ "$GPUVC" ]; then
        setprop prop.gpu.vendor "$GPUVC"
        echo "  setprop prop.gpu.vendor \"$GPUVC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input GPU Renderer"
    GPUR=$(getprop prop.gpu.renderer);
    echo "- Current value: $GPUR"
printf "> "
    read GPURC
    if [ ! "$GPURC" ]; then
        GPURC=$GPUR
    fi
    if [ "$GPURC" ]; then
        setprop prop.gpu.renderer "$GPURC"
        echo "  setprop prop.gpu.renderer \"$GPURC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input IMEI"
    IMEI=$(getprop vmprop.imei);
    echo "- Current value: $IMEI"
printf "> "
    read IMEIC 
    if [ ! "$IMEIC" ]; then
        IMEIC=$IMEI
    fi
    if [ "$IMEIC" ]; then
        setprop vmprop.imei "$IMEIC"
        echo "  setprop vmprop.imei \"$IMEIC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input IMEI SV"
    IMEISV=$(getprop vmprop.imeisv);
    echo "- Current value: $IMEISV"
printf "> "
    read IMEISVC 
    if [ ! "$IMEISVC" ]; then
        IMEISVC=$IMEISV
    fi
    if [ "$IMEISVC" ]; then
        setprop vmprop.imeisv "$IMEISVC"
        echo "  setprop vmprop.imeisv \"$IMEISVC\"" >>.tmp/toolprop.rc
    fi 
    echo "================================="
    echo "- Property will be restored on the next boot"
    echo "- Do you want to keep changes every boot?"
    echo "- Type yes to continue. Enter or type anything to cancel"
printf "> "
    read TPROP
    if [ "$TPROP" == "yes" ]; then
      mkdir /system/etc/init 2>/dev/null
      cp .tmp/toolprop.rc /data/adb/script/post-fs-data.d/tool-setprop.sh 2>/dev/null
      
    fi
    elif [ "$PROPO" == "2" ]; then
    rm -rR /data/adb/script/post-fs-data.d/tool-setprop.sh 2>/dev/null
    echo "- Removed changes!"
    read
    elif [ "$PROPO" == "3" ]; then
    cp busybox/bin/busybox-arm$BIT cat 2>/dev/null
    chmod 777 cat 2>/dev/null
    chmod 777 /system/build.prop 2>/dev/null
    cp /vmos.prop .tmp/vmos.prop 2>/dev/null
    cp /system/build.prop .tmp/build.prop 2>/dev/null
      if [ -w /vmos.prop ]; then
          echo "- This option will disable vmos.prop and move all values to build.prop"
          echo "- You can change VMOS property through build.prop"
          echo "- Change VM information in VMOS Settings won't take effect after merging"
          echo "- Type yes to confirm action"
printf "> "
          read VTB
              if [ "$VTB" = "yes" ]; then 
                  ./cat .tmp/build.prop >backup/build.prop
                  echo "" >/system/build.prop
                  echo "########################" >>/system/build.prop
                 echo "" >>/system/build.prop
                  echo "#== VMOS.PROP VALUES ARE HERE ==" >>/system/build.prop
                  echo "" >>/system/build.prop
                  ./cat .tmp/vmos.prop >>/system/build.prop && chmod 000 /vmos.prop 2>/dev/null
                  echo "" >>/system/build.prop
                  echo "########################" >>/system/build.prop
                 echo "" >>/system/build.prop
                  echo "#== BUILD.PROP VALUES ARE HERE ==" >>/system/build.prop
                  echo "" >>/system/build.prop
                  ./cat backup/build.prop >>/system/build.prop
                  echo "- Success!" && read
              fi
       else
          echo "- Restore vmos.prop values will remove values in build.prop"
          echo "- Change VM information in VMOS Settings will take effect after unmerging"
          echo "- Type yes to confirm action"
printf "> "
          read VTB
              if [ "$VTB" = "yes" ]; then 
                 if [ -f backup/build.prop ]; then
                  cp backup/build.prop /system/build.prop 2>/dev/null
                 fi
                  chmod 777 /vmos.prop
                  echo "- Success!" && read
              fi
        fi      
    fi
elif [ "$ans" == "6" ]; then
clear
echo "================================="
echo " VMOS TOOL TOOLFLASH"
echo "================================="
cp -a template /sdcard/toolflash 2>/dev/null
echo "- Template zip: /sdcard/toolflash/template"
echo "- 1. Flash all zips from /sdcard/toolflash"
echo "- 2. Flash a zip by path"
printf "> "
read FLASH
if [ "$FLASH" == "1" ]; then
  printf "- Preparing flash environment... "
  mkdir /data/adb/flash 2>/dev/null
  cd /sdcard/toolflash

  FLASHFILE=$(find *.zip -prune -type f) 2>/dev/null
  for file in $FLASHFILE; do
  mkdir /data/adb/flash/$file.mod
  cd /
  $bb unzip -o system_root/sdcard/toolflash/$file -d system_root/data/adb/flash/$file.mod &>/dev/null
  done
 
  # cp -a /sdcard/toolflash/* /data/adb/flash 2>/dev/null
  cd /data/adb/flash 2>/dev/null
  FLASHLIST=$(find * -prune -type d) 2>/dev/null
  
  echo "Done!"
  printf "" >/sdcard/toolflash/log.txt
  for dir in $FLASHLIST; do
    if [ ! "$dir" == "template" ]; then
    echo "================================="
    echo "  FLASHING MOD \"$dir\"..."
    echo "================================="
      if [ -f "/data/adb/flash/$dir/update" ]; then
    echo "" >>/sdcard/toolflash/log.txt
    echo "== LOG ERROR: $dir ==" >>/sdcard/toolflash/log.txt
    cd /data/adb/flash/$dir 2>/dev/null && sh /system/.tool/flash.sh 2>>/sdcard/toolflash/log.txt && Re=1
    rm /data/adb/flash/$dir/update 2>/dev/null
      elif [ -f "/data/adb/flash/$dir/error" ]; then
          echo "! Module is not installed"
      elif [ -f "/data/adb/flash/$dir/installed" ]; then
          echo "- Module is installed"
          Re=1
      else
    echo "" >>/sdcard/toolflash/log.txt
    echo "== LOG ERROR: $dir ==" >>/sdcard/toolflash/log.txt
    cd /data/adb/flash/$dir 2>/dev/null && sh /system/.tool/flash.sh 2>>/sdcard/toolflash/log.txt && Re=1
    # rm /sdcard/toolflash/$dir/config.sh 2>/dev/null
    # rm /sdcard/toolflash/$dir/custom.sh 2>/dev/null
    fi
    
    if [ ! "$Re" == "1" ]; then
        echo "! Failed to install \"$dir\" modification"
    fi
    Re=0
    fi
  done
rm -rR /data/adb/flash/* 2>/dev/null
echo "**************************"
echo "- Flash done! Change will take effect after reboot"
read

elif [ "$FLASH" == "2" ]; then
    echo "- Input path to your zip file:"
    printf "> "
    read zip
    if [ -f "/system_root$zip" ]; then
    cd / 2>/dev/null
  mkdir -p ./data/adb/flash/installer 2>/dev/null
  echo "================================="
  echo "== LOG ERROR: $zip ==" >/sdcard/toolflash/log.txt
  echo "- Extracting zip file..."
  $bb unzip -o system_root$zip -d ./data/adb/flash/installer &>/dev/null
  cd /data/adb/flash/installer 2>/dev/null && sh /system/.tool/flash.sh 2>>/sdcard/toolflash/log.txt && Re=1
  rm -rR /data/adb/flash/* 2>/dev/null
  if [ "$Re" == "1" ]; then
    echo "**************************"
    echo "- Flash done! Change will take effect after reboot"
  else
    echo "! Installation failed!"
  fi
   else
       echo "! File not found"
   fi
fi
elif [ "$ans" == "7" ]; then
echo "================================="
echo "- Mount your real SD Card to VM?"
echo "- You can access your files in real SD Card in VM"
echo "- Type yes to continue"
printf "> "
read MOUNT
if [ "$MOUNT" == "yes" ]; then
rm -rR /sdcard/real_storage/* 2>/dev/null
rm -rR /local_disk/* 2>/dev/null
mkdir /sdcard/real_storage 2>/dev/null
mkdir /local_disk 2>/dev/null
ln -s /proc/self/root/sdcard /sdcard/real_storage/sdcard 2>/dev/null && MOUNTS=true
ln -s /proc/self/root/sdcard /local_disk/sdcard 2>/dev/null && MOUNTSX=true
ln -s /proc/self/root/storage /sdcard/real_storage/storage 2>/dev/null && MOUNTS2=true
ln -s /proc/self/root/storage /local_disk/storage 2>/dev/null && MOUNTS2X=true
if [ "$MOUNTS" == "true" ]; then
echo "- You real storage was mounted"
echo " SDCARD:   /sdcard/real_storage/sdcard"
  if [ "$MOUNTS2" == "true" ]; then
      echo " STORAGE:   /sdcard/real_storage/storage"
  fi
read
elif [ "$MOUNTSX" == "true" ]; then
echo "- You real storage was mounted"
echo " SDCARD:   /local_disk/sdcard"
  if [ "$MOUNTS2X" == "true" ]; then
      echo " STORAGE:   /local_disk/storage"
  fi
read
else
echo "- Cannot mount your read SD Card"
read
fi
fi
elif [ "$ans" == "8" ]; then
    echo "================================="
echo "- Do you want to $VAR8?"
echo "- Type yes to continue"
printf "> "
read MOVE
if [ "$MOVE" == "yes" ]; then
TMPR=.tmp/random.txt
      printf "" >$TMPR
      co=$(seq 1 1 10)
      for i in $co; do
          hexs=0123456789abcdef
          hex=$(( $RANDOM % 16))
          echo -n ${hexs:$hex:1} >>$TMPR
      done
      random=$(./busybox/busybox cat $TMPR)
     if [ ! "$ISSDLINK" == "true" ]; then
         if [ "$EXTPATHFS" ]; then
             find $EXTPATHFS/* -prune -empty -type d -delete &>/dev/null
             printf "- Moving data to external storage... "
             find $SDCARD/ -type l -delete &>/dev/null
             mkdir -p $EXTPATHFS/$random 2>/dev/null
             cp -a $SDCARD/.* $EXTPATHFS/$random 2>/dev/null
             cp -a $SDCARD/* $EXTPATHFS/$random 2>/dev/null && rm -rR $SDCARD 2>/dev/null && ln -s $EXTPATHFS/$random $SDCARD 2>/dev/null && MOVESD=1
             if [ "$MOVESD" == "1" ]; then
                 echo "SUCCESS"
             else
                 echo "FAILED"
            fi
            read
        else
            echo "! Could not found external SD Card"
            read
        fi
    else
        printf "- Moving data to internal storage... "
        mkdir $CSDCARD 2>/dev/null
        external=$(readlink $SDCARD)
        cp -a $SDCARD/.* $CSDCARD 2>/dev/null
        cp -a $SDCARD/* $CSDCARD 2>/dev/null && rm -rR $SDCARD/* && rm -rR $SDCARD 2>/dev/null &&  mv $CSDCARD $SDCARD && MOVESD=1
        rm -rR $external 2>/dev/null
        if [ "$MOVESD" == "1" ]; then
            echo "SUCCESS!"
       else
            echo "FAILED"
       fi
       read
   fi




fi
elif [ "$ans" == "9" ]; then
if [ -f "/data/adb/.boot/dual" ]; then
echo "- VM will boot to First space on the next boot"
rm -rR /data/adb/.boot/dual 2>/dev/null
else
echo "- VM will boot to Second space on the next boot"
touch /data/adb/.boot/dual 2>/dev/null
fi

elif [ "$ans" == "10" ]; then
 if [ ! -f "/data/adb/.boot/clear" ]; then
     echo "- Are you sure to clear data in $sname ?"
     echo "- Type \"clear\" to confirm action"
     printf "> "
     read clear
     if [ "$clear" == "clear" ]; then
         echo "- Data in $sname will be clean on the next boot"
         touch /data/adb/.boot/clear
     fi
 else
    echo "- Data in $sname will be clean on the next boot"
    echo "- Do you want to undone?"
    echo "- Type \"undone\" to confirm action"
     printf "> "
     read clear
     if [ "$clear" == "undone" ]; then
         echo "- Data in $sname won't be clean on the next boot"
         rm -rR /data/adb/.boot/clear
     fi
 fi

elif [ "$ans" == "11" ]; then

 clear

 echo "================================="
echo " GOOGLE SERVICES"
echo "================================="
 echo "- 1. Download installer zip"
 echo "- 2. Download un-installer zip"
 echo "- 3. Remove downloaded files"
 printf "> "
 read OPT
 mkdir -p /system/.tool/plugin 2>/dev/null
 [ "$OPT" == "1" -o "$OPT" == "2" ] && echo "- Downloading... please wait"
 cd /system_root 2>/dev/null
 FDIR="./system/.tool/plugin"
 if [ "$OPT" == "1" ]; then
 if [ ! -f "$FDIR/google-installer-$sdk-$cpu.zip" ]; then
cd /system_root 2>/dev/null
URL="https://github.com/HuskyDG/VMOSPro_Google_Services/releases/download/1.1/google-installer-$sdk-$cpu.zip"
 $bb wget -P $FDIR $URL
 zip="$FDIR/google-installer-$sdk-$cpu.zip"
 else
 echo "- File exists!"
 zip="$FDIR/google-installer-$sdk-$cpu.zip"
fi


 elif [ "$OPT" == "2" ]; then
 if [ ! -f "$FDIR/google-uninstaller.zip" ]; then
cd /system_root 2>/dev/null
URL="https://github.com/HuskyDG/VMOSPro_Google_Services/releases/download/1.1/google-uninstaller.zip"
 $bb wget -P $FDIR $URL
 zip="$FDIR/google-uninstaller.zip"
 else
 echo "- File exists!"
 zip="$FDIR/google-uninstaller.zip"
 fi


 elif [ "$OPT" == "3" ]; then
 rm -rR /system/.tool/plugin/google-installer-$sdk-$cpu.zip 2>/dev/null
 rm -rR /system/.tool/plugin/google-uninstaller.zip 2>/dev/null
 echo "- File deleted!"

 fi

if [ -f "$zip" ]; then
  echo "- Do you want to flash it?"
  echo "- Type yes to continue"
  printf "> "
  read flash
  if [ "$flash" == "yes" ]; then
  cd /system_root 2>/dev/null
  mkdir -p ./data/adb/flash/google 2>/dev/null
  $bb unzip -o $zip -d ./data/adb/flash/google &>/dev/null
  cd /data/adb/flash/google 2>/dev/null && sh /system/.tool/flash.sh 2>/dev/null && Re=1
  rm -rR /data/adb/flash/* 2>/dev/null
  if [ "$Re" == "1" ]; then
    echo "- Installation successful!"
    echo "- Reboot to apply changes"
  else
    echo "! Installation failed!"
  fi
  fi
fi

elif [ "$ans" == "0" ]; then
    clear
    exit
else
    NOOPT=1
    main
fi }


if [ ! "$NOOPT" == "1" ]; then
cd /system/.tool
main
fi
