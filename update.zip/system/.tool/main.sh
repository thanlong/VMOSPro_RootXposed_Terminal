#!/system/bin/sh

#####################
# VMOS Pro Tool script by HuskyDG
clear
echo "VMOS PRO TERMINAL TOOL"

sh ./update.sh 9999
./busybox/busybox sleep 1







main(){
if [ -d "/storage/emulated/0" ]; then
SDCARD="/storage/emulated/0"
CSDCARD="/storage/emulated/sdcard"
else
SDCARD="/storage/sdcard"
CSDCARD="/storage/tmp_sdcard"
fi
sdlist=$(find /proc/self/root/storage/* -prune -type d) 2>/dev/null
for sd in $sdlist; do
  if [ -r "$sd/Android" ]; then
  EXTPATH=$sd
  fi
done



ln -s / /system_root &>/dev/null

PACKAGE="
com.vmos.pro
com.vmos.gbi
com.vmos.gbb
"
if [ "$EXTPATH" ]; then
for name in $PACKAGE; do
  mkdir -p $EXTPATH/Android/data/$name/files/expand 2>/dev/null
  if [ -d "$EXTPATH/Android/data/$name/files/expand" ]; then
  EXTPATHFS=$EXTPATH/Android/data/$name/files/expand
  fi
done
fi
ISSDLINK=false
SDLINK=$(find $SDCARD -prune -type l) 2>/dev/null
[ "$SDLINK" ] && ISSDLINK=true

VAR8S="Use SD Card as internal storage";VAR8="Use external SD Card as VM memory storage"

[ ! -d "$SDCARD" ] && VAR8S="Repair internal storage";

[ "$ISSDLINK" == "true" ] && VAR8="Revert internal VM memory storage" && VAR8S="Revert internal storage";

if [ -f "/tool_files/work/.boot/dual" ]; then
VAR9="Switch to Primary userspace"


else
VAR9="Switch to Secondary space"


fi

bb=/tool_files/main/busybox/busybox; dualspace=$(getprop huskydg.tool.dualspace); sname="Secondary userspace"; [ "$dualspace" == "true" ] && sname="Primary userspace";
sdk=$(getprop ro.build.version.sdk); . /tool_files/main/exbin/utils;
cpu=$(getprop ro.product.cpu.abi);

clear; VER=`p orange $TOOLVER`

# print the ui


pd gray "=============================================="
echo "   VMOS PRO TOOL"
echo "   version $VER By HuskyDG"
pd gray "=============================================="
# test system is rw or not
sh ./test_rw.sh 2>/dev/null
if [ -f exit ]; then
read
exit
fi
# print options
pd light_green "TOOL FUNCTION"

echo "  1 - Superuser (Root)"
echo "  2 - Xposed Framework"
echo "  3 - Busybox"
echo "  4 - Wipe dalvik-cache"
echo "  5 - VMOS Props Config"
echo "  6 - Install modifications"
echo "  7 - Mount real storage"
echo "  8 - SDCard Tool"
echo "  9 - $VAR9"
echo "  10 - Wipe data in $sname"
echo "  11 - Google Services"
echo "  12 - Run Termux environment"

pd light_green "TOOL MENU"

[ ! "$(whoami)" == "root" ] && echo "  # - Root mode"
echo "  @ - Update tool"
echo "  0 - Exit"
rm -rR /tool_files/work/flash/* 2>/dev/null
mkdir /sdcard/toolflash 2>/dev/null
rm -rR .tmp/* 2>/dev/null
if [ ! -d ".tmp" ]; then
    mkdir ".tmp"
fi
p none "> "
read ans
if [ "$ans" == "1" ]; then
# execute root script
    cd root
    sh root.sh 9999
elif [ "$ans" == "2" ]; then
# execute xposed script
    cd xposed
    sh xposed.sh 9999
elif [ "$ans" == "3" ]; then
# execute busybox script
    cd busybox
    sh busybox.sh
elif [ "$ans" == "4" ]; then
pd gray "=============================================="
   echo "- Wipe dalvik-cache. Are you sure?"
   echo "- Type yes to confirm"
p none "> "
   read wdalvik
   if [ "$wdalvik" == "yes" ]; then
       rm -rR /data/dalvik-cache
       mkdir /data/dalvik-cache
       echo "- Dalvik-cache wiped!"
       echo "- Next boot will take long time."
       read
       sh main.sh
   else
      pd red "Cancelled"
      read
      sh main.sh
      exit
   fi 

elif [ "$ans" == "5" ]; then
  if [ ! -f /vmos.prop ]; then
      echo "- This option is available for VMOS only!"
      read
      sh main.sh
      exit
  fi
clear
pd gray "=============================================="
echo " VMOS PROPS CONFIG"
pd gray "=============================================="
echo "- Change VMOS property without reboot"
echo "- This will not change anything in vmos.prop file"
echo "- VMOS settings still show old changes"
echo "  1 - View or change some properties"
echo "  2 - Remove apply changes on boot"
echo "  3 - Lock or unlock vmos.prop"
echo "- Press any key or ENTER to come back to main menu"
p none "> "
read PROPO
if [ "$PROPO" == "1" ]; then
echo "- Press ENTER if you don't want to change in current input"


    echo "• Input GPU Vendor"
    GPUV=$(getprop prop.gpu.vendor);
    echo "- Current value: $GPUV" 
p none "> "
    read GPUVC
    if [ ! "$GPUVC" ]; then
        GPUVC=$GPUV
    fi
    if [ "$GPUVC" ]; then
        setprop prop.gpu.vendor "$GPUVC"
        echo "  setprop prop.gpu.vendor \"$GPUVC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input GPU Renderer"
    GPUR=$(getprop prop.gpu.renderer);
    echo "- Current value: $GPUR"
p none "> "
    read GPURC
    if [ ! "$GPURC" ]; then
        GPURC=$GPUR
    fi
    if [ "$GPURC" ]; then
        setprop prop.gpu.renderer "$GPURC"
        echo "  setprop prop.gpu.renderer \"$GPURC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input IMEI"
    IMEI=$(getprop vmprop.imei);
    echo "- Current value: $IMEI"
p none "> "
    read IMEIC 
    if [ ! "$IMEIC" ]; then
        IMEIC=$IMEI
    fi
    if [ "$IMEIC" ]; then
        setprop vmprop.imei "$IMEIC"
        echo "  setprop vmprop.imei \"$IMEIC\"" >>.tmp/toolprop.rc
    fi 
    echo "• Input IMEI SV"
    IMEISV=$(getprop vmprop.imeisv);
    echo "- Current value: $IMEISV"
p none "> "
    read IMEISVC 
    if [ ! "$IMEISVC" ]; then
        IMEISVC=$IMEISV
    fi
    if [ "$IMEISVC" ]; then
        setprop vmprop.imeisv "$IMEISVC"
        echo "  setprop vmprop.imeisv \"$IMEISVC\"" >>.tmp/toolprop.rc
    fi 
    pd gray "=============================================="
    echo "- Property will be restored on the next boot"
    echo "- Do you want to keep changes every boot?"
    echo "- Type yes to continue. Enter or type anything to cancel"
p none "> "
    read TPROP
    if [ "$TPROP" == "yes" ]; then
      mkdir /system/etc/init 2>/dev/null
      cp .tmp/toolprop.rc /tool_files/work/script/post-fs-data.d/tool-setprop.sh 2>/dev/null
      
    fi
    elif [ "$PROPO" == "2" ]; then
    rm -rR /tool_files/work/script/post-fs-data.d/tool-setprop.sh 2>/dev/null
    echo "- Removed changes!"
    read
    elif [ "$PROPO" == "3" ]; then
    
      if [ -w /vmos.prop ]; then
          p none "- ";p purple "vmos.prop";p none " file is currently "; pd green "not locked"
          echo "- If it's locked, you can keep your current property"
          echo "and prevent VMOS from changing it!"
          echo "- Type yes to confirm action"
p none "> "
          read VTB
              if [ "$VTB" = "yes" ]; then 
                  chmod -w /vmos.prop 2>/dev/null
                  echo "- Success!" && read
              fi
       else
          p none "- ";p purple "vmos.prop";p none " file is currently "; pd red "locked"
          echo "- If it is unlocked, VMOS will load the new property" 
          echo "based on VM information change settings."
          echo "- Type yes to confirm action"
p none "> "
          read VTB
              if [ "$VTB" = "yes" ]; then 
                 
                  chmod +w /vmos.prop
                  echo "- Success!" && read
              fi
        fi      
    fi
elif [ "$ans" == "6" ]; then
clear
pd gray "=============================================="
echo " VMOS TOOL TOOLFLASH"
pd gray "=============================================="
cp -a template /sdcard/toolflash 2>/dev/null
echo "- Template zip: /sdcard/toolflash/template"
echo "  1 - Flash all zips from /sdcard/toolflash"
echo "  2 - Flash a zip by path"
p none "> "
read FLASH
if [ "$FLASH" == "1" ]; then
  
  mkdir /tool_files/work/flash 2>/dev/null
  cd /sdcard/toolflash

  FLASHFILE=$(find *.zip -prune -type f) 2>/dev/null
  for file in $FLASHFILE; do
  
  install_mod /sdcard/toolflash/$file $file
  done
 
 


elif [ "$FLASH" == "2" ]; then
    echo "- Input path to your zip file:"
    p none "> "
    read zip
    install_mod $zip installer
fi
elif [ "$ans" == "7" ]; then
pd gray "=============================================="
echo "- Mount your real SD Card to VM?"
echo "- You can access your files in real SD Card in VM"
echo "- Type yes to continue"
p none "> "
read MOUNT
if [ "$MOUNT" == "yes" ]; then
rm -rR /sdcard/real_storage/* 2>/dev/null
rm -rR /local_disk/* 2>/dev/null
mkdir /sdcard/real_storage 2>/dev/null
mkdir /local_disk 2>/dev/null
ln -s /proc/self/root/sdcard /sdcard/real_storage/sdcard 2>/dev/null && MOUNTS=true
ln -s /proc/self/root/sdcard /local_disk/sdcard 2>/dev/null && MOUNTSX=true
ln -s /proc/self/root/storage /sdcard/real_storage/storage 2>/dev/null && MOUNTS2=true
ln -s /proc/self/root/storage /local_disk/storage 2>/dev/null && MOUNTS2X=true
if [ "$MOUNTS" == "true" ]; then
echo "- You real storage was mounted"
echo " SDCARD:   /sdcard/real_storage/sdcard"
  if [ "$MOUNTS2" == "true" ]; then
      echo " STORAGE:   /sdcard/real_storage/storage"
  fi
read
elif [ "$MOUNTSX" == "true" ]; then
echo "- You real storage was mounted"
echo " SDCARD:   /local_disk/sdcard"
  if [ "$MOUNTS2X" == "true" ]; then
      echo " STORAGE:   /local_disk/storage"
  fi
read
else
pd red "Cannot mount your real SD Card"
read
fi
fi
elif [ "$ans" == "8" ]; then
clear
pd gray "=============================================="
echo " SD CARD TOOL"
pd gray "=============================================="
echo "  1 - $VAR8S"
echo "  2 - Move installed app to SD Card"
p none "> "
read optionsd


if [ "$optionsd" == "1" ]; then

    pd gray "=============================================="

if [ ! -d "$SDCARD" ]; then
echo "- Look like you have discarded SDCard"
echo "- Repair internal storage away? <yes/no>"
read MOVE
if [ "$MOVE" == "yes" ]; then
  SDCARD=/storage/sdcard
  [ "$API" == "25" ] && SDCARD=/storage/emulated/0
  rm -rR $SDCARD 2>/dev/null
  mkdir $SDCARD 2>/dev/null
  p none "> "
  echo "- Repair done!"
fi
else

echo "- Do you want to $VAR8?"
echo "- Type yes to continue"
p none "> "
read MOVE
if [ "$MOVE" == "yes" ]; then
     random="$VMID-`random 20`"
     if [ ! "$ISSDLINK" == "true" ]; then
         if [ "$EXTPATHFS" ]; then
             find $EXTPATHFS/* -prune -empty -type d -delete &>/dev/null
             p none "- Moving data to external storage... "
             find $SDCARD/ -type l -delete &>/dev/null
             mkdir -p $EXTPATHFS/$random 2>/dev/null
             cp -a $SDCARD/.* $EXTPATHFS/$random 2>/dev/null
             cp -a $SDCARD/* $EXTPATHFS/$random 2>/dev/null && rm -rR $SDCARD 2>/dev/null && ln -s $EXTPATHFS/$random $SDCARD 2>/dev/null && MOVESD=1
             if [ "$MOVESD" == "1" ]; then
                 echo "SUCCESS"
             else
                 echo "FAILED"
            fi
            read
        else
            pd red "Could not found external SD Card"
            read
        fi
    else
        p none "- Moving data to internal storage... "
        mkdir $CSDCARD 2>/dev/null
        external=$(readlink $SDCARD)
        cp -a $SDCARD/.* $CSDCARD 2>/dev/null
        cp -a $SDCARD/* $CSDCARD 2>/dev/null && rm -rR $SDCARD/* && rm -rR $SDCARD 2>/dev/null &&  mv $CSDCARD $SDCARD && MOVESD=1
        rm -rR $external 2>/dev/null
        if [ "$MOVESD" == "1" ]; then
            echo "SUCCESS!"
       else
            echo "FAILED"
       fi
       read
   fi

fi
fi
elif [ "$optionsd" == "2" ]; then

# check if /mnt/asec is a link
chklnk=`find /mnt/asec -prune -type l` &>/dev/null
[ "$chklnk" ] && ISASECLINK=true

if [ ! "$ISASECLINK" ] && [ "$EXTPATHFS" ]; then
  asec_dir="$EXTPATHFS/$VMID-`random 10`"
  p none  "Mounting writeable SDCard..."
  rm -rR /mnt/asec 2>/dev/null
  mkdir $asec_dir 2>/dev/null && ln -s $asec_dir /mnt/asec 2>/dev/null && echo "DONE" || echo "FAILD"
elif [ ! "$EXTPATHFS" ]; then
  pd red "SD Card not found!!"
fi
if [ "$ISASECLINK" = "true" ]; then
clear
echo "Getting apps list..."

# get app list
LISTAPPDIR=`find /data/app/* -prune -type d`
c=1; q="\n"
mkdir -p $MDIR/.tmp
for i in $LISTAPPDIR; do
    if [ -f "/proc/self/root$VMOS_ROOT_DIR$i/base.apk" ]; then
        i=/proc/self/root$VMOS_ROOT_DIR$i
        echo "APP_$c=$i" >>$MDIR/.tmp/app_list
        app_name=`app_name "$i/base.apk"` 2>/dev/null
        app_label=`app_label "$i/base.apk"` 2>/dev/null
        [ "$(find $i/base.apk -prune -type l)" ] && app_name=$(p green "$app_name")
        q+="  $c - $app_name\n"
        q+=`pd gray "    $app_label"`
        q+="\n"
        c=$(($c+1))
    fi
done
clear
echo "  CHOICE APP YOU WANT"
echo $q
pd gray "To move multiple app, enter multiple number"
p gray "Example: "; echo "1 5 18";
p none "> "
read option
for n in $option; do
app_dir=`grep_prop APP_$n $MDIR/.tmp/app_list`
app_label=`app_label "$app_dir/base.apk"` 2>/dev/null
app_name=`app_name "$app_dir/base.apk"` 2>/dev/null
[ "$apk_dir" ] && apks=`find $app_dir/*.apk -prune` 2>/dev/null
if [ "$n" ] && [ "$app_dir" ]; then
    if [ ! "$(find $app_dir/base.apk -prune -type l)" ]; then
        echo "Move \"$app_name\" to SD Card? <yes/no>"
        p none "> "
        read move
        if [ "$move" == "yes" ]; then
            echo "Moving app to SD Card...";
            mkdir -p /mnt/asec/$app_label 2>/dev/null
            for apk in $apks; do
            apk_name=`basename $apk`
            p none "Moving \"$apk_name\" files... "
            mv $app_dir/$apk_name /mnt/asec/$app_label/$apk_name 2>/dev/null && ln -s /mnt/asec/$app_label/$apk_name $app_dir/$apk_name 2>/dev/null && move_completed=true
            [ "$move_completed" ] && echo "DONE" || echo "FAILED"
            done
        fi
    else
        echo "Move \"$app_name\" back to Internal storage? <yes/no>"
        p none "> "
        read move
        if [ "$move" == "yes" ]; then
            echo "Moving app to Internal storage...";
            for apk in $apks; do
            apk_name=`basename $apk`
            rm -rR $app_dir/$apk_name 2>/dev/null
            p none "Moving \"$apk_name\" files... "
            mv /mnt/asec/$app_label/$apk_name $app_dir/$apk_name 2>/dev/null && move_completed=true
            [ "$move_completed" ] && echo "DONE" || echo "FAILED"
            done
        fi
    fi
fi
done
fi


fi


elif [ "$ans" == "9" ]; then
if [ -f "/tool_files/work/.boot/dual" ]; then
echo "- VM will boot to First space on the next boot"
rm -rR /tool_files/work/.boot/dual 2>/dev/null
else
echo "- VM will boot to Second space on the next boot"
touch /tool_files/work/.boot/dual 2>/dev/null
fi

elif [ "$ans" == "10" ]; then
 if [ ! -f "/tool_files/work/.boot/clear" ]; then
     echo "- Are you sure to clear data in $sname ?"
     echo "- Type \"clear\" to confirm action"
     p none "> "
     read clear
     if [ "$clear" == "clear" ]; then
         echo "- Data in $sname will be clean on the next boot"
         touch /tool_files/work/.boot/clear
     fi
 else
    echo "- Data in $sname will be clean on the next boot"
    echo "- Do you want to undone?"
    echo "- Type \"undone\" to confirm action"
     p none "> "
     read clear
     if [ "$clear" == "undone" ]; then
         echo "- Data in $sname won't be clean on the next boot"
         rm -rR /tool_files/work/.boot/clear
     fi
 fi

elif [ "$ans" == "11" ]; then

 clear

 pd gray "=============================================="
echo " GOOGLE SERVICES"
pd gray "=============================================="
 echo "  1 - Download installer zip and flash"
 echo "  2 - Download un-installer zip and flash"
 echo "  3 - Remove downloaded files"
 p none "> "
 read OPT
 mkdir -p /tool_files/main/plugin 2>/dev/null
 [ "$OPT" == "1" -o "$OPT" == "2" ] && echo "- Downloading... please wait"
 cd /system_root 2>/dev/null
 FDIR="./tool_files/main/plugin"
 FDIRX="/tool_files/main/plugin"
 if [ "$OPT" == "1" ]; then
 if [ ! -f "$FDIR/google-installer-$sdk-$cpu.zip" ]; then
cd /system_root 2>/dev/null
URL="https://github.com/HuskyDG/VMOSPro_Google_Services/releases/download/1.1/google-installer-$sdk-$cpu.zip"
 $bb wget -P $FDIR $URL
 zip="$FDIRX/google-installer-$sdk-$cpu.zip"
 else
 echo "- File exists!"
 zip="$FDIRX/google-installer-$sdk-$cpu.zip"
fi


 elif [ "$OPT" == "2" ]; then
 if [ ! -f "$FDIR/google-uninstaller.zip" ]; then
cd /system_root 2>/dev/null
URL="https://github.com/HuskyDG/VMOSPro_Google_Services/releases/download/1.1/google-uninstaller.zip"
 $bb wget -P $FDIR $URL
 zip="$FDIRX/google-uninstaller.zip"
 else
 echo "- File exists!"
 zip="$FDIRX/google-uninstaller.zip"
 fi


 elif [ "$OPT" == "3" ]; then
 rm -rR /tool_files/main/plugin/google-installer-$sdk-$cpu.zip 2>/dev/null
 rm -rR /tool_files/main/plugin/google-uninstaller.zip 2>/dev/null
 echo "- File deleted!"

 fi

if [ -f "$zip" ]; then
  echo "- Do you want to flash it?"
  echo "- Type yes to continue"
  p none "> "
  read flash
  if [ "$flash" == "yes" ]; then
  install_mod $zip google
  fi
fi
elif [ "$ans" == "#" ]; then
[ ! "$(whoami)" == "root" ] && sudo tool; exit
elif [ "$ans" == "@" ]; then
sh $MDIR/update.sh; exit 0
elif [ "$ans" == "12" ]; then 
if [ ! -d "/tool_files/termux" ]; then
    echo "Termux is not installed!"
    echo "Would you like to install Termux plugin? <yes/no>"
    p none "> "
    read option

    if [ "$option" == "yes" ]; then
        [ "$ABILONG" == "armeabi-v7a" ] && CPU="arm64"
        [ "$ABILONG" == "arm64-v8a" ] && CPU="arm64"
        [ ! "$CPU" ] && pd red "You device is not supported"
        mkdir -p /tool_files/main/plugin 2>/dev/null
        cd /tool_files/main/plugin 2>/dev/null
        UZIP="https://github.com/HuskyDG/Termux-VMOS/releases/download/v1.0/termux-on-terminal-$CPU.zip"
        rm -rR termux.zip.tmp 2>/dev/null
        [ "$CPU" ] && $bb wget -O ./termux.zip.tmp "$UZIP" && mv "./termux.zip.tmp" "./termux.zip"
        [ -f "./termux.zip" ] && install_mod "/tool_files/main/plugin/termux.zip" termux && read && termux
     fi
else
     termux
fi

elif [ "$ans" == "0" ]; then
    clear
    exit
else
    pd light_red "Invalid option!"

fi }

#main

while true; do
main
p yellow "Press Enter to return to the main page"; read
cd $MDIR;
done
