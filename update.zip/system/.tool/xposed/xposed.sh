#!/system/bin/sh
BOOTDIR=/data/adb/.boot

SDK=$(getprop ro.build.version.sdk);
AARCH=$(getprop ro.product.cpu.abi); var1=$1;

[ ! "$var1" == "9999" ] && sh /tool_files/main/update.sh 9999 2>/dev/null

clear; . /tool_files/main/exbin/utils
pd gray "=============================================="
echo "   XPOSED FRAMEWORK"
echo "   version 1.1 By HuskyDG"
pd gray "=============================================="
[ ! "$(whoami)" == "root" ] && pd red "Sorry! This action required root access" && exit;

mkdir $BOOTDIR/system/app 2>/dev/null
sh ../test_rw.sh
echo "  1 - Install Xposed Framework"
echo "  2 - Uninstall Xposed Framework"
echo "  0 - Exit"
p none "[CHOICE]: "
read OPT
if [ "$OPT" == "1" ]; then
  if [ $SDK == 25 ]; then
      if [ "$AARCH" == "arm64-v8a" ]; then
        if [ ! -f "$BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "$BOOTDIR/system/app/XposedInstaller_3.1.5" ]; then
              mkdir $BOOTDIR/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk $BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
        cd 25_64
      else
        if [ ! -f "$BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "$BOOTDIR/system/app/XposedInstaller_3.1.5" ]; then
              mkdir $BOOTDIR/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk $BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
        cd 25
      fi
  elif [ $SDK == 22 ]; then
       if [ ! -f "$BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "$BOOTDIR/system/app/XposedInstaller_3.1.5" ]; then
              mkdir $BOOTDIR/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk $BOOTDIR/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
      cd 22
  elif [ $SDK == 19 ]; then
      cp XposedInstaller_3.1.5.apk $BOOTDIR/system/app/XposedInstaller_3.1.5.apk
      cd 19
  else
      echo "! Wrong version"
      exit
  fi
elif [ "$OPT" == "2" ]; then
  if [ -f "/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
  echo "rm -rR /system/app/XposedInstaller_3.1.5" >>$BOOTDIR/config.sh
  fi
  if [ -f "/system/app/XposedInstaller_3.1.5.apk" ]; then
      echo "rm /system/app/XposedInstaller_3.1.5.apk" >>$BOOTDIR/config.sh
  fi
  if [ ! $SDK == 19 ]; then
  if [ "$AARCH" == "arm64-v8a" ]; then
    cd u_arm64
  else
    cd u_arm
  fi
  else
    cd u_19
  fi
elif [ "$OPT" == "0" ]; then
  clear
  exit
else
  sh xposed.sh
fi
if [ "$OPT" == "1" -o "$OPT" == "2" ]; then

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="

  chmod 777 META-INF/com/google/android/flash-script.sh
  META-INF/com/google/android/flash-script.sh

pd gray "=============================================="
echo "- Changes will take effect after reboot"
read
fi