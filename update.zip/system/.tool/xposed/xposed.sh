#!/system/bin/sh
BOOTDIR=/data/adb/.boot

SDK=$(getprop ro.build.version.sdk);
AARCH=$(getprop ro.product.cpu.abi); var1=$1;

[ ! "$var1" == "9999" ] && sh /tool_files/main/update.sh 9999 2>/dev/null

clear; . /tool_files/main/exbin/utils
pd gray "=============================================="
echo "   XPOSED FRAMEWORK"
echo "   version 1.1 By HuskyDG"
pd gray "=============================================="
[ ! "$(whoami)" == "root" ] && pd red "Sorry! This action required root access" && exit;
sh ../test_rw.sh
if [ -f "/system/framework/XposedBridge.jar" ]; then
pd light_green "Xposed Framework is installed"
echo "Do you want to uninstall? <yes/no>"
OPT=2
else
pd light_red "Xposed Framework not installed"
echo "Do you want to install? <yes/no>"
OPT=1
fi
p none "[CHOICE]: "
read CHOICE
if [ "$CHOICE" == "yes" ]; then
mount -o rw,remount /system 2>/dev/null
if [ "$OPT" == "1" ]; then
  mktouch /data/user_de/0/de.robv.android.xposed.installer/log/error.log 2>/dev/null
  mktouch /data/data/de.robv.android.xposed.installer/log/error.log 2>/dev/null
  if [ $SDK == 25 ]; then
      if [ "$AARCH" == "arm64-v8a" ]; then
        if [ ! -f "/system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "/system_root/system/app/XposedInstaller_3.1.5" ]; then
              mkdir /system_root/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk /system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
        cd 25_64
      else
        if [ ! -f "/system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "/system_root/system/app/XposedInstaller_3.1.5" ]; then
              mkdir /system_root/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk /system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
        cd 25
      fi
  elif [ $SDK == 22 ]; then
       if [ ! -f "/system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
          if [ ! -d "/system_root/system/app/XposedInstaller_3.1.5" ]; then
              mkdir /system_root/system/app/XposedInstaller_3.1.5
          fi
          cp XposedInstaller_3.1.5.apk /system_root/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk
        fi
      cd 22
  elif [ $SDK == 19 ]; then
      cp XposedInstaller_3.1.5.apk /system_root/system/app/XposedInstaller_3.1.5.apk
      cd 19
  else
      echo "! Wrong version"
      exit
  fi
elif [ "$OPT" == "2" ]; then
  if [ -f "/system/app/XposedInstaller_3.1.5/XposedInstaller_3.1.5.apk" ]; then
  rm -rf /system/app/XposedInstaller_3.1.5 2>/dev/null
  fi
  if [ -f "/system/app/XposedInstaller_3.1.5.apk" ]; then
      rm /system/app/XposedInstaller_3.1.5.apk 2>/dev/null
  fi
  if [ ! $SDK == 19 ]; then
  if [ "$AARCH" == "arm64-v8a" ]; then
    cd u_arm64
  else
    cd u_arm
  fi
  else
    cd u_19
  fi
fi
if [ "$OPT" == "1" -o "$OPT" == "2" ]; then

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="

  chmod 777 META-INF/com/google/android/flash-script.sh
  META-INF/com/google/android/flash-script.sh
mount -o ro,remount /system 2>/dev/null
pd gray "=============================================="
echo "Reboot after 3 seconds..."
busybox sleep 3; wboot
fi
fi