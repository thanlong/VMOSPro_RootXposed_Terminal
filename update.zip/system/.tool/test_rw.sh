#!/system/bin/sh

. /system/.tool/exbin/utils
echo "Link: https://bit.ly/2VRtHd7"
rm -rR exit 2>/dev/null


SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);dualspace=$(getprop huskydg.tool.dualspace); sname="Primary"; [ "$dualspace" == "true" ] && sname="Secondary";


if [ "$SDK" == "25" ]; then
ANDR=7.1
elif [ "$SDK" == "22" ]; then
ANDR=5.1
elif [ "$SDK" == "19" ]; then
ANDR=4.4
else
ANDR="Unknown"
fi

if [ "$AARCH" == "arm64-v8a" -o "$AARCH" == "x64" ]; then
IS64BIT=true
BIT=64
else
IS64BIT=false
BIT=32
fi

p none "Android version: ";pd light_blue "$ANDR ($BIT-bit)"


if [ -w "/system/build.prop" ]; then
 p none "Read-write system: ";pd green "true"
else
 p none "Read-write system: ";pd red "false"
fi
p none "User space: ";pd orange "$name"
pd gray "=============================================="
