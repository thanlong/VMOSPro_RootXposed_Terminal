#!/system/bin/sh
execute_script(){
SCRS=$(find /tool_files/work/script/post-fs-data.d/* -type f) && FINDP=true

if [ ! "$FINDP" == "true" ]; then
cd "/"
SCRS=$(find tool_files/work/script/post-fs-data.d/* -type f)
fi


for sc in $SCRS; do
    sh $sc &
done

}
(execute_script &) &>/dev/null