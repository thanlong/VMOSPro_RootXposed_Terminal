#!/system/bin/sh

BBDIR=/system/.tool/busybox
SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);

     if [ "$AARCH" == "arm64-v8a" ]; then
        cp $BBDIR/bin/busybox-arm64 $BBDIR/busybox 2>/dev/null
    elif [ "$AARCH" == "armeabi-v7a" ]; then
        cp $BBDIR/bin/busybox-arm $BBDIR/busybox
    fi

su_bind(){

if [ ! -f "/system/.tool/root/disable" ]; then

if [ -f "/system/xbin/daemonsu" ]; then
FILES="
/sbin/su
/sbin/sx
"
for file in $FILES; do
    if [ ! -f "$file" ]; then
        ln -s /system/xbin/daemonsu $file
    fi
done
fi
fi

}

wait_load(){

/system/.tool/busybox/busybox sleep 10

}

    chmod 777 $BBDIR/busybox 2>/dev/null


SCRS=$(find /data/adb/script/late_start.d/* -type f) && FINDL=true

if [ ! "$FINDL" == "true" ]; then
cd "/"
SCRS=$(find data/adb/script/late_start.d/* -type f)
fi

for sc in $SCRS; do
    sh $sc &
done



### BYPASS ROOT

su_bind
wait_load
rm -rR /data/adb/.boot/config.sh &
rm -rR /data/adb/.boot/system/* &
su_bind
wait_load
su_bind

