#!/system/bin/sh
. /tool_files/main/exbin/utils
BBDIR=/tool_files/main/busybox
EXDIR=/tool_files/main/exbin
SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);



su_bind(){
/tool_files/main/busybox/busybox sleep 5;
if [ ! -f "/tool_files/main/root/disable" ]; then

if [ -f "/system/xbin/daemonsu" ]; then
FILES="
/sbin/su
/sbin/sx
"
for file in $FILES; do
    if [ ! -f "$file" ]; then
        ln -s /system/xbin/daemonsu $file
    fi
done
fi
fi

}

wait_load(){

/tool_files/main/busybox/busybox sleep 3

}

run_daemon(){
wait_load;wait_load;
wait_load;wait_load;
wait_load;
if [ ! "$(mount | grep /sbin)" ]; then
mount -o rw,remount /
rm -rf /root
mkdir /root
ln /sbin/* /root
mount -t tmpfs -o "mode=0755" tmpfs /sbin
ln -s /root/* /sbin
ln -s /data/adb/magisk/magisk /sbin/magisk
mount -o ro,remount /
fi
/data/adb/magisk/magisk --daemon
BINDIR=/sbin
ln -s /data/adb/magisk/magisk $BINDIR/magisk
chmod 755 $BINDIR/magisk
ln -s $BINDIR/magisk $BINDIR/su
ln -s $BINDIR/magisk $BINDIR/resetprop
ln -s $BINDIR/magisk $BINDIR/magiskhide
mkdir -p /data/adb/modules
mkdir -p /sbin/.magisk/modules
mount --bind /data/adb/modules /sbin/.magisk/modules

}

magisk_status=$(grep_prop enable $MDIR/root/plugin.prop);
[ -f "/sdcard/.disable_magisk" ] && magisk_status=false
[ "$magisk_status" == "true" ] && run_daemon &

update(){
sh /tool_files/main/update.sh
}
    

execute_script(){
wait_load; wait_load;rm -rf /data/adb/script;ln -s /tool_files/work/script /data/adb/script;rm -rf /data/adb/.boot;ln -s /tool_files/work/.boot /data/adb/.boot;
SCRIPTDIR=$(find /tool_files/work/script/late_start.d/* -type f) && FINDL=true

if [ ! "$FINDL" == "true" ]; then
cd "/"
SCRIPTDIR=$(find tool_files/work/script/late_start.d/* -type f)
fi

for sc in $SCRIPTDIR; do
    sh $sc &
done
wait_load;wait_load
rm -rf /tool_files/work/.boot/config.sh
rm -rf /tool_files/work/.boot/system/*
rm -rf /tool_files/work/.boot/system/.*

}
(execute_script &) 2>/dev/null

### BYPASS ROOT

su_bind 2>/dev/null
wait_load


(/system/xbin/daemonsu --daemon &) &>/dev/null
(update &) &>/dev/null
(sh /tool_files/main/exbin/exbin &) &>/dev/null