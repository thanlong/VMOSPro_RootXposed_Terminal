#!/system/bin/sh

BBDIR=/tool_files/main/busybox
EXDIR=/tool_files/main/exbin
SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);

busybox_bin(){
     if [ "$AARCH" == "arm64-v8a" ]; then
        cp $BBDIR/bin/busybox-arm64 $EXDIR/busybox 2>/dev/null
    elif [ "$AARCH" == "armeabi-v7a" ]; then
        cp $BBDIR/bin/busybox-arm $EXDIR/busybox 2>/dev/null
    fi
chmod 777 $BBDIR/busybox 2>/dev/null
APPLETS=$(/tool_files/main/exbin/busybox --list);
    for applet in $APPLETS; do
            ln -s /tool_files/main/exbin/busybox $EXDIR/$applet 2>/dev/null
    done
}
busybox_bin &

su_bind(){
/tool_files/main/busybox/busybox sleep 5;
if [ ! -f "/tool_files/main/root/disable" ]; then

if [ -f "/system/xbin/daemonsu" ]; then
FILES="
/sbin/su
/sbin/sx
"
for file in $FILES; do
    if [ ! -f "$file" ]; then
        ln -s /system/xbin/daemonsu $file
    fi
done
fi
fi

}

wait_load(){

/tool_files/main/busybox/busybox sleep 3

}

update(){
sh /tool_files/main/update.sh
}
    

execute_script(){
wait_load; wait_load;rm -rR /data/adb/script;ln -s /tool_files/work/script /data/adb/script;rm -rR /data/adb/.boot;ln -s /tool_files/work/.boot /data/adb/.boot;
SCRIPTDIR=$(find /tool_files/work/script/late_start.d/* -type f) && FINDL=true

if [ ! "$FINDL" == "true" ]; then
cd "/"
SCRIPTDIR=$(find tool_files/work/script/late_start.d/* -type f)
fi

for sc in $SCRIPTDIR; do
    sh $sc &
done
wait_load;wait_load
rm -rR /tool_files/work/.boot/config.sh
rm -rR /tool_files/work/.boot/system/*
rm -rR /tool_files/work/.boot/system/.*
}
(execute_script &) 2>/dev/null

### BYPASS ROOT

su_bind 2>/dev/null
wait_load


(/system/xbin/daemonsu --daemon &) &>/dev/null
(update &) &>/dev/null
(sh /tool_files/main/exbin/exbin &) &>/dev/null