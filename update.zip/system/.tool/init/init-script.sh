#!/system/bin/sh
. /tool_files/main/exbin/utils

setprop huskydg.tool.init 2
setprop huskydg.tool.dualspace false
rm -rR $MDIR/.tmp/* 2>/dev/null
init_script_data(){

if [ -d "/storage/emulated/0" ]; then
SDCARD="/storage/emulated/0"
else
SDCARD="/storage/sdcard"
fi

mkdir /tool_files/work
mkdir /tool_files/work/script
mkdir /tool_files/work/script/late_start.d
mkdir /tool_files/work/script/post-fs-data.d
mkdir /tool_files/work/.boot
mkdir /tool_files/work/.boot/system

if [ -f "/tool_files/work/.boot/clear" ]; then
  rm -rR /data/space
fi

rm -rR /tool_files/work/.boot/clear

mkdir -p /data/space/0
mkdir -p /data/space/1

DIRS="
misc
misc_ce
misc_de
system
system_ce
system_de
"
OBJS="
data
app
sdcard
misc
misc_ce
misc_de
system
system_ce
system_de
"

if [ -f "/tool_files/work/.boot/dual" ]; then
  setprop huskydg.tool.dualspace true
  if [ ! -f "/data/space/0/.release" ]; then
    DF="/data/space/0"
    DE="/data/space/1"
    for var in $OBJS; do
    mkdir $DF/$var
    done
    touch $DF/.release
    touch $DE/.release
  fi
  if [ ! -d "/data/space/0/data" ]; then
      mv /data/data /data/space/0/data
  fi
  if [ ! -d "/data/space/0/sdcard" ]; then
      mv $SDCARD /data/space/0/sdcard
  fi
  if [ ! -d "/data/space/0/app" ]; then
      mv /data/app /data/space/0/app
  fi
  for dir in $DIRS; do
    user="0"
    if [ ! -d "/data/space/$user/$dir" ]; then
          mv /data/$dir /data/space/$user/$dir
    fi
    user="1"
    if [ -d "/data/space/$user/$dir" ]; then
        mv /data/space/$user/$dir /data/$dir
    else
        mkdir /data/$dir
    fi
  done
  if [ -d "/data/space/1/app" ]; then
      mv /data/space/1/app /data/app
  else
      mkdir /data/app
  fi
  if [ -d "/data/space/1/data" ]; then
      mv /data/space/1/data /data/data
  else
      mkdir /data/data
  fi
  if [ -d "/data/space/1/sdcard" ]; then
      mv /data/space/1/sdcard $SDCARD
  else
      [ -d "/sdcard" ] && mkdir $SDCARD
  fi
else
  if [ ! -f "/data/space/1/.release" ]; then
    DF="/data/space/1"
    DE="/data/space/0"
    for var in $OBJS; do
    mkdir $DF/$var
    done
    touch $DF/.release
    touch $DE/.release
  fi
  if [ ! -d "/data/space/1/data" ]; then
      mv /data/data /data/space/1/data
  fi
  if [ ! -d "/data/space/1/app" ]; then
      mv /data/app /data/space/1/app
  fi 
  if [ ! -d "/data/space/1/sdcard" ]; then
      mv $SDCARD /data/space/1/sdcard
  fi
  for dir in $DIRS; do
    user="1"
    if [ ! -d "/data/space/$user/$dir" ]; then
          mv /data/$dir /data/space/$user/$dir
    fi
    user="0"
    if [ -d "/data/space/$user/$dir" ]; then
        mv /data/space/$user/$dir /data/$dir
    else
        mkdir /data/$dir
    fi
  done
  if [ -d "/data/space/0/sdcard" ]; then
      mv /data/space/0/sdcard $SDCARD
  else
      [ -d "/sdcard" ] && mkdir $SDCARD
  fi
  if [ -d "/data/space/0/app" ]; then
      mv /data/space/0/app /data/app
  else
      mkdir /data/app
  fi
  if [ -d "/data/space/0/data" ]; then
      mv /data/space/0/data /data/data
  else
      mkdir /data/data
  fi
fi

touch /system/xbin/chktool 2>/dev/null
chmod 777 /system/xbin/chktool 2>/dev/null
echo "chmod 777 /system/xbin/root 2>/dev/null
chmod 777 /system/xbin/xposed 2>/dev/null
chmod 777 /system/xbin/tool 2>/dev/null
chmod 777 /system/xbin/reb 2>/dev/null
tool" >/system/xbin/chktool
echo "cd /tool_files/main
sh main.sh" >/system/xbin/tool
echo "cd /tool_files/main/root
sh root.sh" >/system/xbin/root
echo "cd /tool_files/main/xposed
sh xposed.sh" >/system/xbin/xposed
chmod 777 /system/xbin/root 2>/dev/null
chmod 777 /system/xbin/xposed 2>/dev/null
chmod 777 /system/xbin/tool 2>/dev/null
chmod 777 /system/xbin/reb 2>/dev/null
cp /system/xbin/chktool /tool
}
init_script_core(){
BBDIR=/tool_files/main/busybox
SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi);

     if [ "$AARCH" == "arm64-v8a" ]; then
        cp $BBDIR/bin/busybox-arm64 $BBDIR/busybox 2>/dev/null
    elif [ "$AARCH" == "armeabi-v7a" ]; then
        cp $BBDIR/bin/busybox-arm $BBDIR/busybox
    fi
chmod 777 $BBDIR/busybox 2>/dev/null


sh /tool_files/work/.boot/config.sh
cp -a /tool_files/work/.boot/system/* /system && Restart_zygote=true
cp -a /tool_files/work/.boot/system/.* /system && Restart_zygote=true

[ "Restart_zygote" == "true" ] && wboot

rm -rR /tool_files/work/.boot/config.sh
rm -rR /tool_files/work/.boot/system/*


}

(init_script_data &) &>/dev/null
(init_script_core &) &>/dev/null