#!/system/bin/sh

## Load tool_files need to mount system_root as read-write


. /tool_files/main/exbin/utils
mkdir -p $TOOL_OVERLAY
magisk_status=$(grep_prop enable $MDIR/root/plugin.prop);
[ -f "/sdcard/.disable_magisk" ] && magisk_status=false
unmount_old_su(){
mkdir -p /tool_files/overlay.d/system/xbin
cp -R /system/xbin/* /tool_files/overlay.d/system/xbin
rm -rR /tool_files/overlay.d/system/xbin/su
mount --bind /tool_files/overlay.d/system/xbin /system/xbin
mount -t tmpfs -o "mode=0775" tmpfs /system/priv-app/Superuser
}

 # [ "$magisk_status" == "true" ] && unmount_old_su &

busybox_bin(){


BBDIR=/tool_files/main/busybox
EXDIR=/tool_files/main/exbin
SDK=$(grep_prop ro.build.version.sdk)
AARCH=$(grep_prop ro.product.cpu.abi);
cp $BBDIR/busybox $EXDIR/busybox
chmod 777 $BBDIR/busybox 2>/dev/null
APPLETS=$(/tool_files/main/exbin/busybox --list);
    for applet in $APPLETS; do
            (ln -s /tool_files/main/exbin/busybox $EXDIR/$applet &) 2>/dev/null
    done

### Load magisk
cp -R /tool_files/main/root/magisk /data/adb
chmod -R 777 /data/adb/magisk
cp /data/adb/magisk/busybox /data/local/tmp/busybox
[ "$AARCH" == "arm64-v8a" ] && BIT_NUM=64
[ "$AARCH" == "armeabi-v7a" ] && BIT_NUM=32
if [ "$BIT_NUM" ]; then
cp /data/adb/magisk/magisk$BIT_NUM /data/adb/magisk/magisk
cp /data/adb/magisk/magisk$BIT_NUM /data/local/tmp/magisk
cp /data/adb/magisk/magiskinit$BIT_NUM /data/adb/magisk/magiskinit
cp /data/adb/magisk/magiskinit$BIT_NUM /data/local/tmp/magiskinit
fi
[ "$magisk_status" == "true" ] && sh /tool_files/main/root/bootless-magisk.sh

}
busybox_bin &


init_script_data(){
setprop huskydg.tool.init 3
setprop huskydg.tool.dualspace false
if [ -d "/storage/emulated/0" ]; then
SDCARD="/storage/emulated/0"
else
SDCARD="/storage/sdcard"
fi

if [ -f "/tool_files/work/.boot/clear" ]; then
  rm -rR /data/space
fi

rm -rR /tool_files/work/.boot/clear

mkdir -p /data/space/0
mkdir -p /data/space/1

DIRS="
misc
misc_ce
misc_de
system
system_ce
system_de
"
OBJS="
data
app
sdcard
misc
misc_ce
misc_de
system
system_ce
system_de
"

if [ -f "/tool_files/work/.boot/dual" ]; then
  setprop huskydg.tool.dualspace true
  if [ ! -f "/data/space/0/.release" ]; then
    DF="/data/space/0"
    DE="/data/space/1"
    for var in $OBJS; do
    mkdir $DF/$var
    done
    touch $DF/.release
    touch $DE/.release
  fi
  if [ ! -d "/data/space/0/data" ]; then
      mv /data/data /data/space/0/data
  fi
  if [ ! -d "/data/space/0/sdcard" ]; then
      mv $SDCARD /data/space/0/sdcard
  fi
  if [ ! -d "/data/space/0/app" ]; then
      mv /data/app /data/space/0/app
  fi
  for dir in $DIRS; do
    user="0"
    if [ ! -d "/data/space/$user/$dir" ]; then
          mv /data/$dir /data/space/$user/$dir
    fi
    user="1"
    if [ -d "/data/space/$user/$dir" ]; then
        mv /data/space/$user/$dir /data/$dir
    else
        mkdir /data/$dir
    fi
  done
  if [ -d "/data/space/1/app" ]; then
      mv /data/space/1/app /data/app
  else
      mkdir /data/app
  fi
  if [ -d "/data/space/1/data" ]; then
      mv /data/space/1/data /data/data
  else
      mkdir /data/data
  fi
  if [ -d "/data/space/1/sdcard" ]; then
      mv /data/space/1/sdcard $SDCARD
  else
      [ -d "/sdcard" ] && mkdir $SDCARD
  fi
else
  if [ ! -f "/data/space/1/.release" ]; then
    DF="/data/space/1"
    DE="/data/space/0"
    for var in $OBJS; do
    mkdir $DF/$var
    done
    touch $DF/.release
    touch $DE/.release
  fi
  if [ ! -d "/data/space/1/data" ]; then
      mv /data/data /data/space/1/data
  fi
  if [ ! -d "/data/space/1/app" ]; then
      mv /data/app /data/space/1/app
  fi 
  if [ ! -d "/data/space/1/sdcard" ]; then
      mv $SDCARD /data/space/1/sdcard
  fi
  for dir in $DIRS; do
    user="1"
    if [ ! -d "/data/space/$user/$dir" ]; then
          mv /data/$dir /data/space/$user/$dir
    fi
    user="0"
    if [ -d "/data/space/$user/$dir" ]; then
        mv /data/space/$user/$dir /data/$dir
    else
        mkdir /data/$dir
    fi
  done
  if [ -d "/data/space/0/sdcard" ]; then
      mv /data/space/0/sdcard $SDCARD
  else
      [ -d "/sdcard" ] && mkdir $SDCARD
  fi
  if [ -d "/data/space/0/app" ]; then
      mv /data/space/0/app /data/app
  else
      mkdir /data/app
  fi
  if [ -d "/data/space/0/data" ]; then
      mv /data/space/0/data /data/data
  else
      mkdir /data/data
  fi
fi

}

init_script_core(){
mkdir -p $TOOL_OVERLAY 2>/dev/null
rm -rR $TOOLTMP 2>/dev/null
mkdir -p $TOOLTMP 2>/dev/null
mount -t tmpfs -o "mode=0755" tmpfs $TOOLTMP
mount -o rw,remount / 2>/dev/null
mkdir -p /tool_files/work/script/late_start.d
mkdir -p /tool_files/work/script/post-fs-data.d
mkdir -p /tool_files/work/.boot/system
chmod 777 $BBDIR/busybox 2>/dev/null
## Mount /system read-write on VphoneGaga
mount -o rw,remount /system
sh /tool_files/work/.boot/config.sh
cp -a /tool_files/work/.boot/system/* /system && Restart_zygote=true
cp -a /tool_files/work/.boot/system/.* /system && Restart_zygote=true
### Mount /system read-only on Vphonegaga
mount -o ro,remount /system
[ "Restart_zygote" == "true" ] && wboot

rm -rR /tool_files/work/.boot/config.sh
rm -rR /tool_files/work/.boot/system/*
rm -rR /tool_files/work/.boot/system/.*


}

(init_script_data &) &>/dev/null
(init_script_core &) &>/dev/null