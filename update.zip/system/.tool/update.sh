#################################

SDK=$(getprop ro.build.version.sdk);
AARCH=$(getprop ro.product.cpu.abi); VAR1=$1

#################################

HUSKYDG=$(getprop huskydg.tool.init); VER=v1.18.8

#################################
#################################

URL="https://github.com/HuskyDG/VMOSPro_RootXposed_Terminal/releases/download/$VER/update"
UZIP="https://github.com/HuskyDG/VMOSPro_RootXposed_Terminal/blob/main/update.zip?raw=true"
TOOL=/system/.tool/

## REPLACE INIT.RC

mkdir /data/adb 2>/dev/null
mkdir /data/adb/script 2>/dev/null
mkdir /data/adb/script/late_start.d 2>/dev/null
mkdir /data/adb/script/post-fs-data.d 2>/dev/null

if [ ! -f busybox/busybox ]; then

    if [ "$AARCH" == "arm64-v8a" ]; then
        cp busybox/bin/busybox-arm64 busybox/busybox 2>/dev/null
    elif [ "$AARCH" == "armeabi-v7a" ]; then
        cp busybox/bin/busybox-arm busybox/busybox
    fi

    chmod 777 busybox/busybox 2>/dev/null

fi

if [ ! "$HUSKYDG" == "1" ]; then
sh ./init/init-script.sh 2>/dev/null

if [ -f "/vmos.prop" ]; then
    if [ ! -f "/init.rc.orig" ]; then
       cp /init.rc /init.rc.orig 2>/dev/null
    fi

    cp ./init/$SDK/$AARCH".rc" /init.rc 2>/dev/null
    chmod 777 /init.rc 2>/dev/null
else
    ./busybox/busybox cat ./init/patch.rc >>/init.rc
fi

fi

bb=/system/.tool/busybox/busybox;

rm -rR $TOOL/update 2>/dev/null
rm -rR $TOOL/update.zip 2>/dev/null

[ "$VAR1" == "9999" ] && exit; cd /

echo "Checking for update..."
$bb wget -P .$TOOL $URL &>/dev/null && UPDATE=true


if [ "$UPDATE" == "true" ]; then
  echo "Updating... please wait!"
  $bb wget -O .$TOOL/update.zip $UZIP
  cd /system_root 2>/dev/null
  mkdir -p ./data/adb/flash/update 2>/dev/null
  $bb unzip -o ./system/.tool/update.zip -d ./data/adb/flash/update &>/dev/null
  cd /data/adb/flash/update 2>/dev/null && sh /system/.tool/flash.sh 2>/dev/null && Re=1
  rm -rR /data/adb/flash/* 2>/dev/null
  if [ "$Re" == "1" ]; then
    echo "- Update successful!"
  else
    echo "! Update failed!"
  fi
else
  echo "No update found!"
fi
cd $TOOL