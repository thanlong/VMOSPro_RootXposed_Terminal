#################################

SDK=$(getprop ro.build.version.sdk); cd /tool_files/main
AARCH=$(getprop ro.product.cpu.abi); VAR1=$1;  . /tool_files/main/exbin/utils;

#################################

HUSKYDG=$(getprop huskydg.tool.init); VER=v$TOOLVER

#################################
#################################

URL="https://github.com/HuskyDG/VMOSPro_RootXposed_Terminal/releases/download/$VER/update"
UZIP="https://github.com/HuskyDG/VMOSPro_RootXposed_Terminal/blob/main/update.zip?raw=true"
TOOL=/tool_files/main/

## REPLACE INIT.RC

mkdir /tool_files/work 2>/dev/null
mkdir /tool_files/work/script 2>/dev/null
mkdir /tool_files/work/script/late_start.d 2>/dev/null
mkdir /tool_files/work/script/post-fs-data.d 2>/dev/null

if [ ! -f busybox/busybox ]; then

    if [ "$AARCH" == "arm64-v8a" ]; then
        cp busybox/bin/busybox-arm64 busybox/busybox 2>/dev/null
    elif [ "$AARCH" == "armeabi-v7a" ]; then
        cp busybox/bin/busybox-arm busybox/busybox
    fi

    chmod 777 busybox/busybox 2>/dev/null

fi

if [ ! "$HUSKYDG" == "3" ]; then
sh ./init/init-script.sh 2>/dev/null

if [ -f "/vmos.prop" ]; then
    if [ ! -f "/init.rc.orig" ]; then
       cp /init.rc /init.rc.orig 2>/dev/null
    fi

    cp ./init/$SDK/$AARCH".rc" /init.rc 2>/dev/null
    chmod 777 /init.rc 2>/dev/null
else
    ./busybox/busybox cat ./init/patch.rc >>/init.rc
fi

fi

bb=/tool_files/main/busybox/busybox;

rm -rf $TOOL/update 2>/dev/null
rm -rf $TOOL/update.zip 2>/dev/null

[ "$VAR1" == "9999" ] && exit; cd /

echo "Checking for update..."
$bb wget -P .$TOOL $URL &>/dev/null && UPDATE=true


if [ "$UPDATE" == "true" ]; then
  echo "Updating... please wait!"
  $bb wget -O .$TOOL/update.zip $UZIP
  install_mod $TOOL/update.zip update
else
  echo "No update found!"
fi
ln -s / /system_root &>/dev/null