#!/system/bin/sh

SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi); . /tool_files/main/exbin/utils
clear
echo "****************************"
echo "   BUSYBOX INSTALLER"
echo "   version 1.1 By HuskyDG"
echo "****************************"
[ ! "$(whoami)" == "root" ] && pd red "Sorry! This action required root access" && exit;
sh ../test_rw.sh 2>/dev/null
if [ -f /system/xbin/busybox -o -f /system/bin/busybox -o -f /sbin/busybox ]; then
  echo "- Busybox is installed"
  echo "- Type yes to uninstall Busybox"
printf "> "
  read UNB
  if [ "$UNB" == "yes" ]; then

    clear
    echo "================================="
    echo "  FLASHING..."
    echo "================================="
    echo "- Uninstalling Busybox..."
    APPLETS=$(busybox --list);
    for applet in $APPLETS; do
        FILES="
/system/xbin/$applet"
        for file in $FILES; do
            if [ -f "$file" ]; then
                rm $file
           fi
        done
    done
    if [ -f /system/xbin/busybox ]; then
    rm /system/xbin/busybox
    fi
    if [ -f /system/bin/busybox ]; then
    rm /system/bin/busybox
    fi
    if [ -f /sbin/busybox ]; then
    rm /sbin/busybox
    fi
    echo "- Done!"
   else
    echo "! Cancelled"
    exit
   fi
else
  echo "- Busybox is not installed"
  echo "- Type yes to install Busybox"
printf "> "
  read INB
  if [ "$INB" == "yes" ]; then

    clear
    echo "================================="
    echo "  FLASHING..."
    echo "================================="
    echo "- Installing Busybox..."
    if [ "$AARCH" == "arm64-v8a" ]; then
    cp bin/busybox-arm64 /system/xbin/busybox
    elif [ "$AARCH" == "armeabi-v7a" ]; then
    cp bin/busybox-arm /system/xbin/busybox
    else
    echo "! Installation failed"
    exit
    fi
    if [ -f /system/xbin/busybox ]; then

       echo "- Setting permissions..."
        chmod 777 /system/xbin/busybox


        echo "- Creating symlinks..."

APPLETS=$(busybox --list);
    for applet in $APPLETS; do
            ln -s /system/xbin/busybox /system/xbin/$applet
    done

        echo "- Done!"
    fi
  else
    echo "! Cancelled"
    exit
  fi
fi
echo "================================="
echo "- Type anything to exit"
read
exit