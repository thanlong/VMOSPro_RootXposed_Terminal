#!/system/bin/sh

SDK=$(getprop ro.build.version.sdk)
AARCH=$(getprop ro.product.cpu.abi); . /tool_files/main/exbin/utils
clear
pd gray "=============================================="
echo "   BUSYBOX INSTALLER"
echo "   version 1.1 By HuskyDG"
pd gray "=============================================="
[ ! "$(whoami)" == "root" ] && pd red "Sorry! This action required root access" && exit;
sh ../test_rw.sh 2>/dev/null
if [ -f /system/xbin/busybox -o -f /system/bin/busybox -o -f /sbin/busybox ]; then
  pd light_green "Busybox is installed"
  echo "Type yes to uninstall Busybox"
p none "[CHOICE]: "
  read UNB
  if [ "$UNB" == "yes" ]; then

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="
    echo "Uninstalling Busybox..."
    mount -o rw,remount /system 2>/dev/null
    APPLETS=$(busybox --list);
    for applet in $APPLETS; do
        FILES="
/system/xbin/$applet"
        for file in $FILES; do
            if [ -f "$file" ]; then
                rm $file
           fi
        done
    done
    if [ -f /system/xbin/busybox ]; then
    rm /system/xbin/busybox
    fi
    if [ -f /system/bin/busybox ]; then
    rm /system/bin/busybox
    fi
    if [ -f /sbin/busybox ]; then
    rm /sbin/busybox
    fi
    mount -o ro,remount /system 2>/dev/null
    pd green "Done!"
   else
    pd red "Cancelled"
    exit
   fi
else
  pd light_red "Busybox is not installed"
  echo "Type yes to install Busybox"
p none "[CHOICE]: "
  read INB
  if [ "$INB" == "yes" ]; then

    clear
    pd gray "=============================================="
    echo "  FLASHING..."
    pd gray "=============================================="
    echo "Installing Busybox..."
    mount -o rw,remount /system 2>/dev/null
    if [ "$AARCH" == "arm64-v8a" ]; then
    cp bin/busybox-arm64 /system/xbin/busybox
    elif [ "$AARCH" == "armeabi-v7a" ]; then
    cp bin/busybox-arm /system/xbin/busybox
    else
    pd red "Installation failed"
    exit
    fi
    if [ -f /system/xbin/busybox ]; then

       echo "Setting permissions..."
        chmod 777 /system/xbin/busybox


        echo "Creating symlinks..."

APPLETS=$(busybox --list);
    for applet in $APPLETS; do
            ln -s /system/xbin/busybox /system/xbin/$applet
    done
        mount -o ro,remount /system 2>/dev/null
        pd green "Done!"
    fi
  else
    pd red "Cancelled"
    exit
  fi
fi