#!/system/bin/sh
# Load tool util function
. /system/.tool/exbin/utils
# load new path for terminal
sh /system/.tool/exbin/exbin