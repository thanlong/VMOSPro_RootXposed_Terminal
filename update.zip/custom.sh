#!/system/bin/sh
if [ ! -d "/tool_files" ] && [ -d "/system/.tool" ]; then
mkdir -p /tool_files
mv /system/.tool /tool_files/main
ln -s /tool_files/main /system/.tool
fi


# Load tool util function
. /system/.tool/exbin/utils
# load new path for terminal
sh /system/.tool/exbin/exbin